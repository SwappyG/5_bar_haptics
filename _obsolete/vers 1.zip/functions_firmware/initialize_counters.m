function initialize_counters(s826_obj, C)
    
    % NOTE, C is a struct containing all constants
    
    % Iterate through both arms
    for i = 1:size(C.MOTORS,1)
        
        % Iterate through all joints in arm
        for j = 1:size(C.MOTORS,2)

            % Set the counter to quadrature decode mode
            s826_obj.CounterModeWrite(  C.BOARD_NUM, ...
                                        C.MOTORS(i,j), ... 
                                        s826_obj.CM_K_QUADX4);
                                        
%             % Set parameters for the snapshot function
%             s826_obj.CounterSnapshotConfigWrite(C.BOARD_NUM, ...
%                                                 C.MOTORS(i,j), ...
%                                                 16, ...
%                                                 0);

            % Enable the snapshot function
            s826_obj.CounterStateWrite( C.BOARD_NUM, ...
                                        C.MOTORS(i,j), ... 
                                        1);

%             % Read the first snapshot
%             s826_obj.CounterSnapshotRead(   C.BOARD_NUM, ...
%                                             C.MOTORS(i,j), ...
%                                             s826_obj.WAIT_INFINITE) %s826_obj.WAIT_INFINITE);
                                        
        end
    end
    
end
