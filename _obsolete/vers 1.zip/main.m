%% 826 Initialize

addpath('./classes');
addpath('./constants');
addpath('./functions_application');
addpath('./functions_firmware');

% import the API
import s826.*
import s826_custom.*

% load the constants into the workspace
constants

% create an instance of the s826 class (API for Sensoray 826 card)
s826_obj = s826();

% initialize the API
[API_load_err, board_flags] = initialize_API(s826_obj, ...
                                         C.DLL_PATH, ...
                                         C.HDR_PATH, ...
                                         C.BOARD_NUM);

% TO DO
    % Handle API_load_err and board_flag errs here
                                     
% Initialize the encoder counters
initialize_counters(s826_obj, C);

% TO DO
    % Figure out how to home/reset encoders

                                     
%% Create Containers to Store Data

% Create empty arrays to store robot state data
% Stores time stamps when encoders are read for each motor
% DIM 1: [PREV or CURR]  |  DIM 2: [ARM_#]  |  DIM 3: [JOINT_#]
tstamps = zeros(C.LEN_HISTORY, size(C.MOTORS,1), size(C.MOTORS,2));

% Stores the angle of each joint
% DIM 1: [PREV or CURR]  |  DIM 2: [ARM_#]  |  DIM 3: [JOINT_#]
angles = zeros(C.LEN_HISTORY, size(C.MOTORS,1), size(C.MOTORS,2));

% Stores the position of the tip
% DIM 1: [PREV or CURR]  |  DIM 2: [ARM_#] | DIM 3: [x y theta]
positions = zeros(C.LEN_HISTORY, size(C.MOTORS,1), 3);

% Stores the angular velocity of each joint
% DIM 1: [ARM_#]  |  DIM 2: [JOINT_#]
ang_velos = zeros(size(C.MOTORS,1), size(C.MOTORS,2));

% Stores the velocity of the tip
% DIM 1: [ARM_#] | DIM 2: [x y theta]
velocities = zeros(size(C.MOTORS,1), 3);


%% Main Routine

tic
index = 1;
history = cell(10000, 1);

% Loop
while (index < 10000)
    
     % Store the current time stamp and angles into the prev ones
    tstamps(C.PREV, :, :) = tstamps(C.CURR, :, :);    
    angles(C.PREV, :, :) = angles(C.CURR, :, :); 
    
    % Read encoders and update new angles / time stamps
    [angles(C.CURR, :, :) , tstamps(C.CURR, :, :)] = get_angles(s826_obj, C);
    
    history{index} = squeeze(angles(C.CURR,1,1:2));
    index = index + 1;
    
            %     % Calculate the angular velocity based on the angles / tstamps
            %     ang_velos = calc_ang_velos(angles, tstamps, C);
            %     
            %     % Move the current positions to the prev ones
            %     positions(C.PREV, :, :) = squeeze(positions(C.CURR, :, :)); 
            %     
            %     % Perform forward kinematics to get the new current position
            %     positions(C.CURR, :, :) = forward_kinematics(squeeze(angles(C.CURR, :, :)), C); 
            %     
            %     % Calculate the velocity based on positions / tstamps
            %     velocities = calc_velocity(positions, tstamps, C);
            %     
    
    if mod(round(index/2000), 2)
        angles(C.CURR,2,1:2) = [0.2 0];
    else
        angles(C.CURR,2,1:2) = [0 0];
    end
    
    % Determine the output voltages based on current pos / velo
    cmd_voltages = run_controller(angles, velocities, C); 
    
    % Send the voltage cmds to the servo controller through the 826
    err = send_voltage_cmds(s826_obj, cmd_voltages, C); 
    
            % TO DO:
                % Handle errors in sending information to through the 826

            % TO DO:
                % Get some kind of hardware button to escape out of infinite loop

end


send_voltage_cmds(s826_obj, [0 0 0; 0 0 0], C);

history = vec2mat(cell2mat(history), 2)';
plot(1:length(history),history(1,:));
hold on
plot(1:length(history),history(2,:));
hold off



