%% Constants

C = struct;

% API Related Constants
C.HDR_PATH = 'C:\Users\adgomes\Documents\5 Bar Haptics Project\sdk_826_win_3.3.9\s826_3.3.9\api\826api.h';               % Path to API header
C.DLL_PATH = 'C:\Users\adgomes\Documents\5 Bar Haptics Project\sdk_826_win_3.3.9\s826_3.3.9\api\x64\s826.dll';     % Path to API executable
C.BOARD_NUM = 0;

% Arm Joint Enumeration
C.ARM_1_FOREARM_MOTOR = 0;
C.ARM_1_UPPERARM_MOTOR = 1;
C.ARM_1_TURNTABLE_MOTOR = 2;

C.ARM_2_FOREARM_MOTOR = 3;
C.ARM_2_UPPERARM_MOTOR = 4;
C.ARM_2_TURNTABLE_MOTOR = 5;

C.MOTORS = [C.ARM_1_FOREARM_MOTOR, C.ARM_1_UPPERARM_MOTOR];

C.NUM_MOTORS = 2;

% Arm Dims
C.ARM_DIMS = [1, 1] ; %, 1, 1, 1;
               % 1, 1, 1, 1, 1   ];

% Time stamp
C.LEN_HISTORY = 1;
C.TSTAMP_CONV_FACTOR = 1;
C.CURR = 1;
C.PREV = 2;

% Encoder
C.ENCODER_CT_PER_REV = 4*65535;
C.ENCODER_RAD_PER_CT = 2*pi/C.ENCODER_CT_PER_REV;
C.ENCODER_ZERO_CT = [100000, 100000]; %, 100000; 100000, 100000, 100000];
C.ANGLE_MAX = [pi/3, pi/6]; %, pi/3; 0, 0, 0];
C.ANGLE_MIN = [-pi/4, -pi/4]; %, -pi/3; 0, 0, 0];

% Voltage Limits
C.MAX_VOLT = [5, 5, 5; 
              5, 5, 5];
C.MIN_VOLT = [-5, -5, -5; 
              -5, -5, -5];

