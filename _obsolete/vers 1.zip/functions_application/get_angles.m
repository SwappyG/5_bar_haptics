function [angles, tstamps] = get_angles(s826_obj, C)

    % NOTE, C is a struct containing all constants

    % Create empty arrays to accept the values
    angles = zeros(size(C.MOTORS,1), size(C.MOTORS,2));
    tstamps = zeros(size(C.MOTORS,1), size(C.MOTORS,2));
    
    % Iterate through both arms
    for i = 1:size(C.MOTORS,1)
        
        % Iterate through all joints in arm
        for j = 1:size(C.MOTORS,2)
            
            % Read the encoder and record the angle / tstamp
            s826_obj.CounterSnapshot(C.BOARD_NUM, C.MOTORS(i,j));
            [~,enc,t_raw,~] = s826_obj.CounterSnapshotRead(  C.BOARD_NUM, ...
                                                            C.MOTORS(i,j), ... 
                                                            0);
            
            % Adjust the tstamp to appropriate units
            tstamps(i,j) = t_raw*C.TSTAMP_CONV_FACTOR;
            
            % Adjust the encoder counts to appropriate angles
            angles(i,j) = (double(enc) - C.ENCODER_ZERO_CT(i,j)) * C.ENCODER_RAD_PER_CT; 
            
        end
    end

end