function cmd_voltages = run_controller(angles, velocities, C)

    % NOTE, C is a struct containing all constants
    
    % Create empty cmd_voltages vector
    cmd_voltages = zeros(size(C.MOTORS,1), size(C.MOTORS,2));
    
    gain = 0.25;
    err = squeeze(angles(C.CURR,2,:)) - squeeze(angles(C.CURR,1,:));
    cmd_voltages(1, :) = (err*gain)';

end